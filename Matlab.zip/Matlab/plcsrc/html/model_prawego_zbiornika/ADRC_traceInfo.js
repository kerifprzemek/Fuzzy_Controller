function RTW_Sid2UrlHash() {
	this.urlHashMap = new Array();
	/* <S1>/Sum */
	this.urlHashMap["model_prawego_zbiornika:92"] = "model_prawego_zbiornika.st:71";
	/* <S3>/Discrete-Time
Integrator */
	this.urlHashMap["model_prawego_zbiornika:80:398"] = "model_prawego_zbiornika.st:40,47,70,89";
	/* <S3>/Linear extended state observer */
	this.urlHashMap["model_prawego_zbiornika:80:27"] = "model_prawego_zbiornika.st:69,90";
	/* <S5>/Extended state feedback robust controller */
	this.urlHashMap["model_prawego_zbiornika:80:35"] = "model_prawego_zbiornika.st:46";
	/* <S6>:1 */
	this.urlHashMap["model_prawego_zbiornika:80:27:1"] = "model_prawego_zbiornika.st:72";
	/* <S6>:1:10 */
	this.urlHashMap["model_prawego_zbiornika:80:27:1:10"] = "model_prawego_zbiornika.st:73";
	/* <S6>:1:22 */
	this.urlHashMap["model_prawego_zbiornika:80:27:1:22"] = "model_prawego_zbiornika.st:74,77";
	/* <S6>:1:23 */
	this.urlHashMap["model_prawego_zbiornika:80:27:1:23"] = "model_prawego_zbiornika.st:75,78";
	/* <S6>:1:11 */
	this.urlHashMap["model_prawego_zbiornika:80:27:1:11"] = "model_prawego_zbiornika.st:76";
	/* <S6>:1:12 */
	this.urlHashMap["model_prawego_zbiornika:80:27:1:12"] = "model_prawego_zbiornika.st:79";
	/* <S6>:1:13 */
	this.urlHashMap["model_prawego_zbiornika:80:27:1:13"] = "model_prawego_zbiornika.st:80";
	/* <S6>:1:35 */
	this.urlHashMap["model_prawego_zbiornika:80:27:1:35"] = "model_prawego_zbiornika.st:81";
	/* <S6>:1:14 */
	this.urlHashMap["model_prawego_zbiornika:80:27:1:14"] = "model_prawego_zbiornika.st:82";
	/* <S6>:1:39 */
	this.urlHashMap["model_prawego_zbiornika:80:27:1:39"] = "model_prawego_zbiornika.st:83";
	/* <S6>:1:40 */
	this.urlHashMap["model_prawego_zbiornika:80:27:1:40"] = "model_prawego_zbiornika.st:84";
	/* <S6>:1:16 */
	this.urlHashMap["model_prawego_zbiornika:80:27:1:16"] = "model_prawego_zbiornika.st:85";
	/* <S6>:1:17 */
	this.urlHashMap["model_prawego_zbiornika:80:27:1:17"] = "model_prawego_zbiornika.st:86";
	/* <S6>:1:18 */
	this.urlHashMap["model_prawego_zbiornika:80:27:1:18"] = "model_prawego_zbiornika.st:87";
	/* <S7>/Last element of estimated extended state */
	this.urlHashMap["model_prawego_zbiornika:80:254"] = "msg=rtwMsg_notTraceable&block=model_prawego_zbiornika:80:254";
	/* <S8>:1 */
	this.urlHashMap["model_prawego_zbiornika:80:254:1"] = "model_prawego_zbiornika.st:91";
	/* <S8>:1:2 */
	this.urlHashMap["model_prawego_zbiornika:80:254:1:2"] = "model_prawego_zbiornika.st:92";
	/* <S10>:1 */
	this.urlHashMap["model_prawego_zbiornika:80:35:1"] = "model_prawego_zbiornika.st:48";
	/* <S10>:1:8 */
	this.urlHashMap["model_prawego_zbiornika:80:35:1:8"] = "model_prawego_zbiornika.st:49";
	/* <S10>:1:17 */
	this.urlHashMap["model_prawego_zbiornika:80:35:1:17"] = "model_prawego_zbiornika.st:50,53";
	/* <S10>:1:18 */
	this.urlHashMap["model_prawego_zbiornika:80:35:1:18"] = "model_prawego_zbiornika.st:51,54";
	/* <S10>:1:9 */
	this.urlHashMap["model_prawego_zbiornika:80:35:1:9"] = "model_prawego_zbiornika.st:52";
	/* <S10>:1:10 */
	this.urlHashMap["model_prawego_zbiornika:80:35:1:10"] = "model_prawego_zbiornika.st:55";
	/* <S10>:1:25 */
	this.urlHashMap["model_prawego_zbiornika:80:35:1:25"] = "model_prawego_zbiornika.st:56";
	/* <S10>:1:26 */
	this.urlHashMap["model_prawego_zbiornika:80:35:1:26"] = "model_prawego_zbiornika.st:57";
	/* <S10>:1:12 */
	this.urlHashMap["model_prawego_zbiornika:80:35:1:12"] = "model_prawego_zbiornika.st:58";
	/* <S10>:1:13 */
	this.urlHashMap["model_prawego_zbiornika:80:35:1:13"] = "model_prawego_zbiornika.st:59";
	/* <S13>/Saturation */
	this.urlHashMap["model_prawego_zbiornika:80:107"] = "model_prawego_zbiornika.st:61,67";
	this.getUrlHash = function(sid) { return this.urlHashMap[sid];}
}
RTW_Sid2UrlHash.instance = new RTW_Sid2UrlHash();
function RTW_rtwnameSIDMap() {
	this.rtwnameHashMap = new Array();
	this.sidHashMap = new Array();
	this.rtwnameHashMap["<Root>"] = {sid: "model_prawego_zbiornika"};
	this.sidHashMap["model_prawego_zbiornika"] = {rtwname: "<Root>"};
	this.rtwnameHashMap["<S1>/Ref"] = {sid: "model_prawego_zbiornika:120"};
	this.sidHashMap["model_prawego_zbiornika:120"] = {rtwname: "<S1>/Ref"};
	this.rtwnameHashMap["<S1>/fdbck"] = {sid: "model_prawego_zbiornika:121"};
	this.sidHashMap["model_prawego_zbiornika:121"] = {rtwname: "<S1>/fdbck"};
	this.rtwnameHashMap["<S1>/ADRC controller"] = {sid: "model_prawego_zbiornika:80"};
	this.sidHashMap["model_prawego_zbiornika:80"] = {rtwname: "<S1>/ADRC controller"};
	this.rtwnameHashMap["<S1>/Sum"] = {sid: "model_prawego_zbiornika:92"};
	this.sidHashMap["model_prawego_zbiornika:92"] = {rtwname: "<S1>/Sum"};
	this.rtwnameHashMap["<S1>/controlSignal"] = {sid: "model_prawego_zbiornika:122"};
	this.sidHashMap["model_prawego_zbiornika:122"] = {rtwname: "<S1>/controlSignal"};
	this.rtwnameHashMap["<S2>/controlError"] = {sid: "model_prawego_zbiornika:80:3"};
	this.sidHashMap["model_prawego_zbiornika:80:3"] = {rtwname: "<S2>/controlError"};
	this.rtwnameHashMap["<S2>/ "] = {sid: "model_prawego_zbiornika:80:4"};
	this.sidHashMap["model_prawego_zbiornika:80:4"] = {rtwname: "<S2>/ "};
	this.rtwnameHashMap["<S2>/From"] = {sid: "model_prawego_zbiornika:80:7"};
	this.sidHashMap["model_prawego_zbiornika:80:7"] = {rtwname: "<S2>/From"};
	this.rtwnameHashMap["<S2>/From1"] = {sid: "model_prawego_zbiornika:80:243"};
	this.sidHashMap["model_prawego_zbiornika:80:243"] = {rtwname: "<S2>/From1"};
	this.rtwnameHashMap["<S2>/From2"] = {sid: "model_prawego_zbiornika:80:56"};
	this.sidHashMap["model_prawego_zbiornika:80:56"] = {rtwname: "<S2>/From2"};
	this.rtwnameHashMap["<S2>/From3"] = {sid: "model_prawego_zbiornika:80:60"};
	this.sidHashMap["model_prawego_zbiornika:80:60"] = {rtwname: "<S2>/From3"};
	this.rtwnameHashMap["<S2>/From4"] = {sid: "model_prawego_zbiornika:80:143"};
	this.sidHashMap["model_prawego_zbiornika:80:143"] = {rtwname: "<S2>/From4"};
	this.rtwnameHashMap["<S2>/From5"] = {sid: "model_prawego_zbiornika:80:10"};
	this.sidHashMap["model_prawego_zbiornika:80:10"] = {rtwname: "<S2>/From5"};
	this.rtwnameHashMap["<S2>/From6"] = {sid: "model_prawego_zbiornika:80:11"};
	this.sidHashMap["model_prawego_zbiornika:80:11"] = {rtwname: "<S2>/From6"};
	this.rtwnameHashMap["<S2>/From7"] = {sid: "model_prawego_zbiornika:80:146"};
	this.sidHashMap["model_prawego_zbiornika:80:146"] = {rtwname: "<S2>/From7"};
	this.rtwnameHashMap["<S2>/Goto"] = {sid: "model_prawego_zbiornika:80:14"};
	this.sidHashMap["model_prawego_zbiornika:80:14"] = {rtwname: "<S2>/Goto"};
	this.rtwnameHashMap["<S2>/Goto1"] = {sid: "model_prawego_zbiornika:80:15"};
	this.sidHashMap["model_prawego_zbiornika:80:15"] = {rtwname: "<S2>/Goto1"};
	this.rtwnameHashMap["<S2>/Goto2"] = {sid: "model_prawego_zbiornika:80:53"};
	this.sidHashMap["model_prawego_zbiornika:80:53"] = {rtwname: "<S2>/Goto2"};
	this.rtwnameHashMap["<S2>/Goto3"] = {sid: "model_prawego_zbiornika:80:16"};
	this.sidHashMap["model_prawego_zbiornika:80:16"] = {rtwname: "<S2>/Goto3"};
	this.rtwnameHashMap["<S2>/Goto4"] = {sid: "model_prawego_zbiornika:80:142"};
	this.sidHashMap["model_prawego_zbiornika:80:142"] = {rtwname: "<S2>/Goto4"};
	this.rtwnameHashMap["<S2>/Goto5"] = {sid: "model_prawego_zbiornika:80:145"};
	this.sidHashMap["model_prawego_zbiornika:80:145"] = {rtwname: "<S2>/Goto5"};
	this.rtwnameHashMap["<S2>/Linear extended state observer"] = {sid: "model_prawego_zbiornika:80:21"};
	this.sidHashMap["model_prawego_zbiornika:80:21"] = {rtwname: "<S2>/Linear extended state observer"};
	this.rtwnameHashMap["<S2>/Observer output"] = {sid: "model_prawego_zbiornika:80:244"};
	this.sidHashMap["model_prawego_zbiornika:80:244"] = {rtwname: "<S2>/Observer output"};
	this.rtwnameHashMap["<S2>/State feedback robust controller"] = {sid: "model_prawego_zbiornika:80:30"};
	this.sidHashMap["model_prawego_zbiornika:80:30"] = {rtwname: "<S2>/State feedback robust controller"};
	this.rtwnameHashMap["<S2>/controllerBandwidthIn"] = {sid: "model_prawego_zbiornika:80:386"};
	this.sidHashMap["model_prawego_zbiornika:80:386"] = {rtwname: "<S2>/controllerBandwidthIn"};
	this.rtwnameHashMap["<S2>/inputGainParameterIn"] = {sid: "model_prawego_zbiornika:80:390"};
	this.sidHashMap["model_prawego_zbiornika:80:390"] = {rtwname: "<S2>/inputGainParameterIn"};
	this.rtwnameHashMap["<S2>/observerBandwidthIn"] = {sid: "model_prawego_zbiornika:80:388"};
	this.sidHashMap["model_prawego_zbiornika:80:388"] = {rtwname: "<S2>/observerBandwidthIn"};
	this.rtwnameHashMap["<S2>/selectedObserverOutput"] = {sid: "model_prawego_zbiornika:80:397"};
	this.sidHashMap["model_prawego_zbiornika:80:397"] = {rtwname: "<S2>/selectedObserverOutput"};
	this.rtwnameHashMap["<S2>/controlSignal"] = {sid: "model_prawego_zbiornika:80:37"};
	this.sidHashMap["model_prawego_zbiornika:80:37"] = {rtwname: "<S2>/controlSignal"};
	this.rtwnameHashMap["<S3>/controlError"] = {sid: "model_prawego_zbiornika:80:22"};
	this.sidHashMap["model_prawego_zbiornika:80:22"] = {rtwname: "<S3>/controlError"};
	this.rtwnameHashMap["<S3>/controlSignal"] = {sid: "model_prawego_zbiornika:80:23"};
	this.sidHashMap["model_prawego_zbiornika:80:23"] = {rtwname: "<S3>/controlSignal"};
	this.rtwnameHashMap["<S3>/externalInputGainParameter"] = {sid: "model_prawego_zbiornika:80:54"};
	this.sidHashMap["model_prawego_zbiornika:80:54"] = {rtwname: "<S3>/externalInputGainParameter"};
	this.rtwnameHashMap["<S3>/externalObserverBandwidth"] = {sid: "model_prawego_zbiornika:80:141"};
	this.sidHashMap["model_prawego_zbiornika:80:141"] = {rtwname: "<S3>/externalObserverBandwidth"};
	this.rtwnameHashMap["<S3>/Discrete-Time Integrator"] = {sid: "model_prawego_zbiornika:80:398"};
	this.sidHashMap["model_prawego_zbiornika:80:398"] = {rtwname: "<S3>/Discrete-Time Integrator"};
	this.rtwnameHashMap["<S3>/Linear extended state observer"] = {sid: "model_prawego_zbiornika:80:27"};
	this.sidHashMap["model_prawego_zbiornika:80:27"] = {rtwname: "<S3>/Linear extended state observer"};
	this.rtwnameHashMap["<S3>/estimatedExtendedState"] = {sid: "model_prawego_zbiornika:80:28"};
	this.sidHashMap["model_prawego_zbiornika:80:28"] = {rtwname: "<S3>/estimatedExtendedState"};
	this.rtwnameHashMap["<S4>/estimatedExtendedState"] = {sid: "model_prawego_zbiornika:80:245"};
	this.sidHashMap["model_prawego_zbiornika:80:245"] = {rtwname: "<S4>/estimatedExtendedState"};
	this.rtwnameHashMap["<S4>/Only estimated control error"] = {sid: "model_prawego_zbiornika:80:331"};
	this.sidHashMap["model_prawego_zbiornika:80:331"] = {rtwname: "<S4>/Only estimated control error"};
	this.rtwnameHashMap["<S4>/Only estimated total disturbance"] = {sid: "model_prawego_zbiornika:80:249"};
	this.sidHashMap["model_prawego_zbiornika:80:249"] = {rtwname: "<S4>/Only estimated total disturbance"};
	this.rtwnameHashMap["<S4>/Whole estimated extended state"] = {sid: "model_prawego_zbiornika:80:246"};
	this.sidHashMap["model_prawego_zbiornika:80:246"] = {rtwname: "<S4>/Whole estimated extended state"};
	this.rtwnameHashMap["<S4>/selectedObserverOutput"] = {sid: "model_prawego_zbiornika:80:252"};
	this.sidHashMap["model_prawego_zbiornika:80:252"] = {rtwname: "<S4>/selectedObserverOutput"};
	this.rtwnameHashMap["<S5>/estimatedExtendedState"] = {sid: "model_prawego_zbiornika:80:34"};
	this.sidHashMap["model_prawego_zbiornika:80:34"] = {rtwname: "<S5>/estimatedExtendedState"};
	this.rtwnameHashMap["<S5>/externalInputGainParameter"] = {sid: "model_prawego_zbiornika:80:59"};
	this.sidHashMap["model_prawego_zbiornika:80:59"] = {rtwname: "<S5>/externalInputGainParameter"};
	this.rtwnameHashMap["<S5>/externalControllerBandwidth"] = {sid: "model_prawego_zbiornika:80:144"};
	this.sidHashMap["model_prawego_zbiornika:80:144"] = {rtwname: "<S5>/externalControllerBandwidth"};
	this.rtwnameHashMap["<S5>/Dead time"] = {sid: "model_prawego_zbiornika:80:127"};
	this.sidHashMap["model_prawego_zbiornika:80:127"] = {rtwname: "<S5>/Dead time"};
	this.rtwnameHashMap["<S5>/Extended state feedback robust controller"] = {sid: "model_prawego_zbiornika:80:35"};
	this.sidHashMap["model_prawego_zbiornika:80:35"] = {rtwname: "<S5>/Extended state feedback robust controller"};
	this.rtwnameHashMap["<S5>/Saturation"] = {sid: "model_prawego_zbiornika:80:97"};
	this.sidHashMap["model_prawego_zbiornika:80:97"] = {rtwname: "<S5>/Saturation"};
	this.rtwnameHashMap["<S5>/controlSignal"] = {sid: "model_prawego_zbiornika:80:36"};
	this.sidHashMap["model_prawego_zbiornika:80:36"] = {rtwname: "<S5>/controlSignal"};
	this.rtwnameHashMap["<S6>:1"] = {sid: "model_prawego_zbiornika:80:27:1"};
	this.sidHashMap["model_prawego_zbiornika:80:27:1"] = {rtwname: "<S6>:1"};
	this.rtwnameHashMap["<S6>:1:10"] = {sid: "model_prawego_zbiornika:80:27:1:10"};
	this.sidHashMap["model_prawego_zbiornika:80:27:1:10"] = {rtwname: "<S6>:1:10"};
	this.rtwnameHashMap["<S6>:1:22"] = {sid: "model_prawego_zbiornika:80:27:1:22"};
	this.sidHashMap["model_prawego_zbiornika:80:27:1:22"] = {rtwname: "<S6>:1:22"};
	this.rtwnameHashMap["<S6>:1:23"] = {sid: "model_prawego_zbiornika:80:27:1:23"};
	this.sidHashMap["model_prawego_zbiornika:80:27:1:23"] = {rtwname: "<S6>:1:23"};
	this.rtwnameHashMap["<S6>:1:11"] = {sid: "model_prawego_zbiornika:80:27:1:11"};
	this.sidHashMap["model_prawego_zbiornika:80:27:1:11"] = {rtwname: "<S6>:1:11"};
	this.rtwnameHashMap["<S6>:1:12"] = {sid: "model_prawego_zbiornika:80:27:1:12"};
	this.sidHashMap["model_prawego_zbiornika:80:27:1:12"] = {rtwname: "<S6>:1:12"};
	this.rtwnameHashMap["<S6>:1:13"] = {sid: "model_prawego_zbiornika:80:27:1:13"};
	this.sidHashMap["model_prawego_zbiornika:80:27:1:13"] = {rtwname: "<S6>:1:13"};
	this.rtwnameHashMap["<S6>:1:35"] = {sid: "model_prawego_zbiornika:80:27:1:35"};
	this.sidHashMap["model_prawego_zbiornika:80:27:1:35"] = {rtwname: "<S6>:1:35"};
	this.rtwnameHashMap["<S6>:1:14"] = {sid: "model_prawego_zbiornika:80:27:1:14"};
	this.sidHashMap["model_prawego_zbiornika:80:27:1:14"] = {rtwname: "<S6>:1:14"};
	this.rtwnameHashMap["<S6>:1:39"] = {sid: "model_prawego_zbiornika:80:27:1:39"};
	this.sidHashMap["model_prawego_zbiornika:80:27:1:39"] = {rtwname: "<S6>:1:39"};
	this.rtwnameHashMap["<S6>:1:40"] = {sid: "model_prawego_zbiornika:80:27:1:40"};
	this.sidHashMap["model_prawego_zbiornika:80:27:1:40"] = {rtwname: "<S6>:1:40"};
	this.rtwnameHashMap["<S6>:1:16"] = {sid: "model_prawego_zbiornika:80:27:1:16"};
	this.sidHashMap["model_prawego_zbiornika:80:27:1:16"] = {rtwname: "<S6>:1:16"};
	this.rtwnameHashMap["<S6>:1:17"] = {sid: "model_prawego_zbiornika:80:27:1:17"};
	this.sidHashMap["model_prawego_zbiornika:80:27:1:17"] = {rtwname: "<S6>:1:17"};
	this.rtwnameHashMap["<S6>:1:18"] = {sid: "model_prawego_zbiornika:80:27:1:18"};
	this.sidHashMap["model_prawego_zbiornika:80:27:1:18"] = {rtwname: "<S6>:1:18"};
	this.rtwnameHashMap["<S7>/estimatedExtendedState"] = {sid: "model_prawego_zbiornika:80:250"};
	this.sidHashMap["model_prawego_zbiornika:80:250"] = {rtwname: "<S7>/estimatedExtendedState"};
	this.rtwnameHashMap["<S7>/Last element of estimated extended state"] = {sid: "model_prawego_zbiornika:80:254"};
	this.sidHashMap["model_prawego_zbiornika:80:254"] = {rtwname: "<S7>/Last element of estimated extended state"};
	this.rtwnameHashMap["<S7>/selectedObserverOutput"] = {sid: "model_prawego_zbiornika:80:251"};
	this.sidHashMap["model_prawego_zbiornika:80:251"] = {rtwname: "<S7>/selectedObserverOutput"};
	this.rtwnameHashMap["<S8>:1"] = {sid: "model_prawego_zbiornika:80:254:1"};
	this.sidHashMap["model_prawego_zbiornika:80:254:1"] = {rtwname: "<S8>:1"};
	this.rtwnameHashMap["<S8>:1:2"] = {sid: "model_prawego_zbiornika:80:254:1:2"};
	this.sidHashMap["model_prawego_zbiornika:80:254:1:2"] = {rtwname: "<S8>:1:2"};
	this.rtwnameHashMap["<S9>/In1"] = {sid: "model_prawego_zbiornika:80:128"};
	this.sidHashMap["model_prawego_zbiornika:80:128"] = {rtwname: "<S9>/In1"};
	this.rtwnameHashMap["<S9>/Dead time off"] = {sid: "model_prawego_zbiornika:80:129"};
	this.sidHashMap["model_prawego_zbiornika:80:129"] = {rtwname: "<S9>/Dead time off"};
	this.rtwnameHashMap["<S9>/Dead time on"] = {sid: "model_prawego_zbiornika:80:132"};
	this.sidHashMap["model_prawego_zbiornika:80:132"] = {rtwname: "<S9>/Dead time on"};
	this.rtwnameHashMap["<S9>/Out1"] = {sid: "model_prawego_zbiornika:80:135"};
	this.sidHashMap["model_prawego_zbiornika:80:135"] = {rtwname: "<S9>/Out1"};
	this.rtwnameHashMap["<S10>:1"] = {sid: "model_prawego_zbiornika:80:35:1"};
	this.sidHashMap["model_prawego_zbiornika:80:35:1"] = {rtwname: "<S10>:1"};
	this.rtwnameHashMap["<S10>:1:8"] = {sid: "model_prawego_zbiornika:80:35:1:8"};
	this.sidHashMap["model_prawego_zbiornika:80:35:1:8"] = {rtwname: "<S10>:1:8"};
	this.rtwnameHashMap["<S10>:1:17"] = {sid: "model_prawego_zbiornika:80:35:1:17"};
	this.sidHashMap["model_prawego_zbiornika:80:35:1:17"] = {rtwname: "<S10>:1:17"};
	this.rtwnameHashMap["<S10>:1:18"] = {sid: "model_prawego_zbiornika:80:35:1:18"};
	this.sidHashMap["model_prawego_zbiornika:80:35:1:18"] = {rtwname: "<S10>:1:18"};
	this.rtwnameHashMap["<S10>:1:9"] = {sid: "model_prawego_zbiornika:80:35:1:9"};
	this.sidHashMap["model_prawego_zbiornika:80:35:1:9"] = {rtwname: "<S10>:1:9"};
	this.rtwnameHashMap["<S10>:1:10"] = {sid: "model_prawego_zbiornika:80:35:1:10"};
	this.sidHashMap["model_prawego_zbiornika:80:35:1:10"] = {rtwname: "<S10>:1:10"};
	this.rtwnameHashMap["<S10>:1:25"] = {sid: "model_prawego_zbiornika:80:35:1:25"};
	this.sidHashMap["model_prawego_zbiornika:80:35:1:25"] = {rtwname: "<S10>:1:25"};
	this.rtwnameHashMap["<S10>:1:26"] = {sid: "model_prawego_zbiornika:80:35:1:26"};
	this.sidHashMap["model_prawego_zbiornika:80:35:1:26"] = {rtwname: "<S10>:1:26"};
	this.rtwnameHashMap["<S10>:1:12"] = {sid: "model_prawego_zbiornika:80:35:1:12"};
	this.sidHashMap["model_prawego_zbiornika:80:35:1:12"] = {rtwname: "<S10>:1:12"};
	this.rtwnameHashMap["<S10>:1:13"] = {sid: "model_prawego_zbiornika:80:35:1:13"};
	this.sidHashMap["model_prawego_zbiornika:80:35:1:13"] = {rtwname: "<S10>:1:13"};
	this.rtwnameHashMap["<S11>/In1"] = {sid: "model_prawego_zbiornika:80:98"};
	this.sidHashMap["model_prawego_zbiornika:80:98"] = {rtwname: "<S11>/In1"};
	this.rtwnameHashMap["<S11>/Saturation off"] = {sid: "model_prawego_zbiornika:80:99"};
	this.sidHashMap["model_prawego_zbiornika:80:99"] = {rtwname: "<S11>/Saturation off"};
	this.rtwnameHashMap["<S11>/Saturation on"] = {sid: "model_prawego_zbiornika:80:102"};
	this.sidHashMap["model_prawego_zbiornika:80:102"] = {rtwname: "<S11>/Saturation on"};
	this.rtwnameHashMap["<S11>/controlSignal"] = {sid: "model_prawego_zbiornika:80:105"};
	this.sidHashMap["model_prawego_zbiornika:80:105"] = {rtwname: "<S11>/controlSignal"};
	this.rtwnameHashMap["<S12>/In1"] = {sid: "model_prawego_zbiornika:80:130"};
	this.sidHashMap["model_prawego_zbiornika:80:130"] = {rtwname: "<S12>/In1"};
	this.rtwnameHashMap["<S12>/Out1"] = {sid: "model_prawego_zbiornika:80:131"};
	this.sidHashMap["model_prawego_zbiornika:80:131"] = {rtwname: "<S12>/Out1"};
	this.rtwnameHashMap["<S13>/In1"] = {sid: "model_prawego_zbiornika:80:103"};
	this.sidHashMap["model_prawego_zbiornika:80:103"] = {rtwname: "<S13>/In1"};
	this.rtwnameHashMap["<S13>/Saturation"] = {sid: "model_prawego_zbiornika:80:107"};
	this.sidHashMap["model_prawego_zbiornika:80:107"] = {rtwname: "<S13>/Saturation"};
	this.rtwnameHashMap["<S13>/controlSignal"] = {sid: "model_prawego_zbiornika:80:104"};
	this.sidHashMap["model_prawego_zbiornika:80:104"] = {rtwname: "<S13>/controlSignal"};
	this.getSID = function(rtwname) { return this.rtwnameHashMap[rtwname];}
	this.getRtwname = function(sid) { return this.sidHashMap[sid];}
}
RTW_rtwnameSIDMap.instance = new RTW_rtwnameSIDMap();
